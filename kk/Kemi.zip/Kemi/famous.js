const people = [
    {name: "Jope Ruonansuu", occupation: "Näyttelijä, koomikko"},
    {name: "Heidi Kyrö", occupation: "Laulaja"},
    {name: "Suvi Tiilikainen", occupation: "Malli"},
    {name: "Mika Halvari", occupation: "Kuulantyöntäjä"},
    {name: "Jari Lipponen", occupation: "Jousiammunta"},
    {name: "Paavo Väyrynen", occupation: "Poliitikko"},
    {name: "Tony Kakko", occupation: "Sonata Artican Laulaja"},
]

whateverElement.addEventListener("event type", () => {
    const searchInput = document.querySelector('.input')
}
